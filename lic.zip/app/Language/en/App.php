<?php

return [
    // Navbar
    'MyAccount' => 'My Account',
    'Users' => 'Users',
    'Logs' => 'Logs',
    'Settings' => 'Settings',

    // Users
    'TotalUsers' => 'Total Users',
    'NewUsers' => 'New Users',
    'ActiveUsers' => 'Active Users',
    'CreateUser' => 'Create User',

    'Name' => 'Name',
    'Email' => 'Email',
    'Status' => 'Status',

    //Edit User
    'EditUser' => 'Edit User',

    //Register User
    'RegisterNewUser' => 'Register New User',
    'Register' => 'Register',
    'Password' => 'Password',
    'PasswordConfirm' => 'Password Confirm',
    'RegisterSuccess' => 'User registered successfully!',
    'EnableUserSuccess' => 'Enable successful',

    'AccountNotDeleted' => 'You cannot delete your own account!',
    'AreYouSure' => 'Are you sure you want to delete this account?',
    'AccountDeleted' => 'Account deleted successfully!',

    //Logs
    'UserLogs' => 'Login Logs',
    'Date' => 'Date',
    'Time' => 'Time',
    'Name' => 'Name',
    'IP Address' => 'IP Address',
    'Browser' => 'Browser',

    //Settings
    'System' => 'System',
    'SystemDescription' => 'Application settings, language, time zones and other environments.',
    'DefaultLanguage' => 'Default Language',
    'TimeZone' => 'Time Zone',
    'DateFormat' => 'Date Format',
    'TimeFormat' => 'Time Format',
    'IpRestriction' => 'IP Restriction',
    'IpRestrictionPlaceholder' => 'Enter IP addresses, if more than one add comma after each IP address.',

    'Email' => 'Email',
    'EmailSettingsDescription' => 'Email SMTP settings, notifications and others related to email.',
    'SenderName' => "Sender's Name",
    'SenderEmail' => "Sender's Email",
    'Protocol' => 'Protocol',
    'ProtocolSelect' => 'Select Protocol',
    'SMTPHost' => 'SMTP Host',
    'SMTPPort' => 'SMTP Port',
    'SMTPUser' => 'SMTP Username',
    'SMTPPassword' => 'SMTP Password',

    //Profile
    'FirstName' => 'First Name',
    'LastName' => 'Last Name',
    'NickName' => 'Nickname',

    'ContactInfo' => 'Contact Info',
    'UpdateProfile' => 'Update Profile',

    'LoginAccess' => 'Login Access',
    'CurrentPassword' => 'Current Password',
    'NewPassword' => 'New Password',
    'ConfirmNewPassword' => 'Confirm New Password',
    'UpdatePassword' => 'Update Password',

    'AccountRemoval' => 'Account Removal',
    'AccountRemovalDescription' => 'Be careful, this action cannot be undone!',
    'DeleteAccount' => 'Delete Account',
    'ConfirmDeleteAccount' => 'Are you sure you want to delete your account?',

    //Licencias
    'Licenses' => 'Licenses',
    'TotalLicenses' => 'Total Licenses',
    'NewLicenses' => 'New Licenses',
    'ActiveLicenses' => 'Active Licenses',
    'CreateLicense' => 'Create License',
    'ProjectName' => 'Project Name',
    'ProjectUrl' => 'Project Url',
    'LicenseType' => 'License Type',
    'LicenseKey' => 'License Key',
    'RedirectUrl' => 'Redirect Url',
    'Trial' => 'Trial',
    'Yearly' => 'Yearly',
    'LifeTime' => 'Life Time',
    'StartDate' => 'Start Date',
    'EndDate' => 'End Date',

    //register license
    'EnableLicenseSuccess' => '¡License enabled successfully!',
    'RegisterLicenseSuccess' => '¡License registered successfully!',

    //edit license
    'EditLicense' => 'Edit License',

    'AddNewKeySuccess' => '¡New key added successfully!',
    'LicenseDeleted' => '¡License deleted successfully!',
    'LicenseAreYouSure' => 'Are you sure you want to delete this license?',

    //Notifications
    'WellDone' => '¡Well done!',
    'NoticationsError' => 'Sorry, there was a problem!',
    'NoticationsMultipleError' => 'Sorry, there were multiple errors!',
    'AnEmailUpdateRequestOn' => 'An e-mail update was requested on ',
    'IfYouDidntRequestThisChange' => "If you didn't request this change, please contact us as soon as possible!",

    //reset
    'PasswordUpdateRequestedOn' => 'A password update was requested on ',
    'ClickFollowingLinkChangePassword' => 'Please click the following link to change your password!',

    //common
    'SaveChanges' => 'Save Changes',
    'Search' => 'Search',
    'Edit' => 'Edit',
    'Delete' => 'Delete',
    'Previous' => 'Previous',
    'Next' => 'Next',
    'Showing' => 'Showing',
    'Entries' => 'entries',
    'Inlast30Days' => 'in last 30 days',
    'Logout' => 'Logout',
    'Active' => 'Active',
    'Inactive' => 'Inactive',
    'Enable' => 'Enable',
    'Disable' => 'Disable',
    'Return' => 'Return',
    'Update' => 'Update',
    'Cancel' => 'Cancel',
    'UpdateSuccess' => 'Updated successfully!',
    'LogSuccess' => 'Login successful!',
    'LogFailed' => 'Login failed!',
];