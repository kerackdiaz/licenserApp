<?php

return [
    // Registro
    'registration' 			=> 'Registro',
    'name' 					=> 'Nombre',
    'email' 				=> 'Dirección de correo electrónico',
    'password'				=> 'Contraseña',
    'passwordAgain'			=> 'Contraseña nuevamente',
    'register'				=> 'Registrarse',
    'alreadyRegistered'		=> '¿Ya estás registrado? ¡Inicia sesión!',

    // Iniciar/cerrar sesión
    'login'					    => 'Iniciar sesión',
    'logout'				    => 'Cerrar sesión',
    'forgotYourPassword'	    => '¿Olvidaste tu contraseña?',
    'loggedInWelcome'           => '¡Bienvenido {0}! Has iniciado sesión.',

    // Contraseña olvidada
    'forgottenPassword'		    => 'Contraseña olvidada',
    'typeEmail'				    => 'Ingresa tu dirección de correo electrónico',
    'setNewPassword'		    => 'Establecer nueva contraseña',

    // Restablecer contraseña
    'resetPassword'			    => 'Restablecer contraseña',
    'newPassword'			    => 'Nueva contraseña',
    'newPasswordAgain'		    => 'Nueva contraseña nuevamente',
    'passwordResetRequest'      => 'Solicitud de restablecimiento de contraseña',

    // Cuenta
    'accountSettings'		    => 'Configuración de la cuenta',
    'changeEmail'               => 'Cambiar dirección de correo electrónico',
    'changeEmailInfo'           => 'Si cambias esto, te enviaremos un correo electrónico a tu nueva dirección para confirmarla.',
    'newEmail'                  => 'Nueva dirección de correo electrónico',
    'pendingEmail'              => 'Nueva dirección de correo electrónico pendiente (Revisa tu correo electrónico para confirmar)',
    'confirmEmail'              => 'Confirma tu dirección de correo electrónico',
    'emailUpdateRequest'        => 'Solicitud de actualización de correo electrónico',
    'changePassword'            => 'Cambiar contraseña',
    'currentPassword'           => 'Contraseña actual',
    'update'                    => 'Actualizar',
    'deleteAccount'             => 'Eliminar cuenta',
    'deleteAccountInfo'         => '¡Ten cuidado, esta acción no se puede deshacer!',
    'areYouSure'                => '¿Estás seguro?',

    // Error y éxito
    'passwordMismatch'          => '¡Las contraseñas deben coincidir!',
    'registrationSuccess'       => '¡Éxito! ¡Activa tu cuenta haciendo clic en el enlace de activación en el correo electrónico que te hemos enviado!',
    'activationNoUser'          => 'No hay usuario con este código de activación.',
    'activationSuccess'         => '¡Activación exitosa! ¡Ahora puedes iniciar sesión en tu cuenta!',
    'wrongCredentials'          => '¡Credenciales incorrectas!',
    'notActivated'              => 'Esta cuenta aún no está activada.',
    'updateSuccess'             => '¡La actualización fue exitosa!',
    'accountDeleted'            => '¡La cuenta se eliminó con éxito!',
    'emailUpdateStarted'        => '¡Éxito! ¡Verifica tu nueva dirección haciendo clic en el enlace del correo electrónico que te hemos enviado!',
    'confirmEmailSuccess'       => '¡Confirmación exitosa! Tu nueva dirección de correo electrónico está activa.',
    'passwordUpdateSuccess'     => '¡La contraseña se actualizó correctamente!',
    'wrongEmail'                => '¡Dirección de correo electrónico incorrecta!',
    'forgottenPasswordEmail' => '¡Se ha enviado un correo electrónico con instrucciones a la dirección indicada!',
    'emailAlreadySent' => '¡Ya se ha enviado un correo electrónico a esta dirección!',
    'invalidRequest' => '¡Solicitud inválida!',
    // Usuarios
    'enableUser'                => 'Activación exitosa!',
];