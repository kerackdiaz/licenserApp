<?php

return [
    // Navbar
    'MyAccount' => 'Hola!',
    'Users' => 'Usuarios',
    'Logs' => 'Logs Login',
    'Settings' => 'Configuraciones',

    // Users
    'TotalUsers' => 'Total de Usuarios',
    'NewUsers' => 'Nuevos Usuarios',
    'ActiveUsers' => 'Usuarios Activos',
    'CreateUser' => 'Crear Usuario',

    'Name' => 'Nombre',
    'Email' => 'Correo Electrónico',
    'Status' => 'Estado',

    //Edit User
    'EditUser' => 'Editar Usuario',

    //Register User
    'RegisterNewUser' => 'Registrar Nuevo Usuario',
    'Register' => 'Registrar',
    'Password' => 'Contraseña',
    'PasswordConfirm' => 'Confirmar Contraseña',
    'RegisterSuccess' => '¡Usuario registrado correctamente!',
    'EnableUserSuccess' => 'Activación exitosa',

    'AccountNotDeleted' => 'No puedes eliminar tu propia cuenta!',
    'AreYouSure' => '¿Estás seguro de que quieres eliminar esta cuenta?',
    'AccountDeleted' => '¡Cuenta eliminada correctamente!',

    //Logs
    'UserLogs' => 'Registros de Inicio de Sesión',
    'Date' => 'Fecha',
    'Time' => 'Hora',
    'Name' => 'Nombre',
    'IPAddress' => 'Dirección IP',
    'Browser' => 'Navegador',

    //Settings
    'System' => 'Sistema',
    'SystemDescription' => 'Configuraciones de la aplicación, idioma, zonas horarias y otros entornos.',
    'DefaultLanguage' => 'Idioma Predeterminado',
    'TimeZone' => 'Zona Horaria',
    'DateFormat' => 'Formato de Fecha',
    'TimeFormat' => 'Formato de Hora',
    'IpRestriction' => 'Restricción de IP',
    'IpRestrictionPlaceholder' => 'Ingrese las direcciones IP, si hay más de una, agregue una coma después de cada dirección IP.',

    'Email' => 'Correo Electrónico',
    'EmailSettingsDescription' => 'Configuraciones SMTP de correo electrónico, notificaciones y otros relacionados con el correo electrónico.',
    'SenderName' => "Nombre del Remitente",
    'SenderEmail' => "Correo Electrónico del Remitente",
    'Protocol' => 'Protocolo',
    'ProtocolSelect' => 'Seleccionar Protocolo',
    'SMTPHost' => 'Host SMTP',
    'SMTPPort' => 'Puerto SMTP',
    'SMTPUser' => 'Usuario SMTP',
    'SMTPPassword' => 'Contraseña SMTP',

    //Profile
    'Profile' => 'Perfil',
    'FirstName' => 'Nombre',
    'LastName' => 'Apellido',
    'NickName' => 'Nickname',

    'ContactInfo' => 'Información de Contacto',
    'UpdateProfile' => 'Actualizar Perfil',

    'LoginAccess' => 'Acceso a Inicio de Sesión',
    'CurrentPassword' => 'Contraseña Actual',
    'NewPassword' => 'Nueva Contraseña',
    'ConfirmNewPassword' => 'Confirmar Nueva Contraseña',
    'UpdatePassword' => 'Actualizar Contraseña',

    'AccountRemoval' => 'Eliminación de Cuenta',
    'AccountRemovalDescription' => '¡Ten cuidado, esta acción no se puede deshacer!',
    'DeleteAccount' => 'Eliminar Cuenta',
    'ConfirmDeleteAccount' => '¿Estás seguro de que quieres eliminar tu cuenta?',

    //Licencias
    'Licenses' => 'Licencias',
    'TotalLicenses' => 'Total de Licencias',
    'NewLicenses' => 'Nuevas Licencias',
    'ActiveLicenses' => 'Licencias Activas',
    'CreateLicense' => 'Crear Licencia',
    'UserName' => 'Nombre de Usuario',
    'ProjectName' => 'Nombre del Proyecto',
    'ProjectUrl' => 'URL del Proyecto',
    'LicenseType' => 'Tipo de Licencia',
    'LicenseKey' => 'Clave de Licencia',
    'RedirectUrl' => 'URL de Redirección',
    'Trial' => 'Demo',
    'Yearly' => 'Anual',
    'LifeTime' => 'Vitalicia',
    'StartDate' => 'Inicio',
    'EndDate' => 'Finalización',

    //register license
    'EnableLicenseSuccess' => '¡Licencia Activada correctamente!',
    'RegisterLicenseSuccess' => '¡Licencia registrada correctamente!',

    //edit license
    'EditLicense' => 'Editar Licencia',

    //add new license
    'RegisterNewLicense' => 'Registrar Nueva Licencia',

    //licenses type
    'LicenseTypes' => 'Tipos de Licencia',
    'EnableLicenseTypeSuccess' => '¡Tipo de Licencia Activada correctamente!',
    'LicenseTypeDeleted' => '¡Tipo de Licencia eliminada correctamente!',
    'RegisterLicenseTypeSuccess' => '¡Tipo de Licencia registrada correctamente!',
    'CreateLicenseType' => 'Crear Tipo de Licencia',
    'LicenseTypeAreYouSure' => '¿Estás seguro de que quieres eliminar este tipo de licencia?',
    'RegisterNewLicenseType' => 'Registrar Nuevo Tipo de Licencia',
    'EditLicenseType' => 'Editar Tipo de Licencia',
    

    'AddNewKeySuccess' => '¡Nueva clave agregada correctamente!',
    'LicenseDeleted' => '¡Licencia eliminada correctamente!',
    'LicenseAreYouSure' => '¿Estás seguro de que quieres eliminar esta licencia?',


    //Notifications
    'WellDone' => '¡Bien Hecho!',
    'NoticationsError' => 'Lo sentimos, hubo un problema!',
    'NoticationsMultipleError' => 'Lo sentimos, hubo varios errores!',

    'AnEmailUpdateRequestOn' => 'Un correo electrónico de actualización fue solicitado en ',
    'IfYouDidntRequestThisChange' => 'Si no solicitó este cambio, ¡contáctenos lo antes posible!',

    //reset
    'PasswordUpdateRequestedOn' => 'Una solicitud de actualización de contraseña fue solicitada en ',
    'ClickFollowingLinkChangePassword' => 'Por favor, haga clic en el siguiente enlace para cambiar su contraseña:',

    //common
    'SaveChanges' => 'Guardar Cambios',
    'Search' => 'Buscar',
    'Edit' => 'Editar',
    'Delete' => 'Eliminar',
    'Previous' => 'Anterior',
    'Next' => 'Siguiente',
    'Showing' => 'Mostrando',
    'Entries' => 'entradas',
    'Inlast30Days' => 'en los últimos 30 días',
    'Logout' => 'Cerrar Sesión',
    'Active' => 'Activo',
    'Inactive' => 'Inactivo',
    'Enable' => 'Habilitar',
    'Disable' => 'Deshabilitar',
    'Return' => 'Regresar',
    'Update' => 'Actualizar',
    'Cancel' => 'Cancelar',
    'UpdateSuccess' => '¡Actualización exitosa!',
    'LogSuccess' => 'Login exitoso!',
    'LogFailed' => 'Login fallido!',


];