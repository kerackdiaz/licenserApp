<?php
namespace App\Controllers\Auth;

use CodeIgniter\Controller;
use CodeIgniter\I18n\Time;
use Config\Email;
use Config\Services;
use App\Models\LicenseTypeModel;

class LicenseTypesController extends Controller
{

	/**
	 * Access to current session.
	 *
	 * @var \CodeIgniter\Session\Session
	 */
	protected $session;

	/**
	 * Authentication settings.
	 */
	protected $config;


    //--------------------------------------------------------------------

	public function __construct()
	{
		// start session
		$this->session = Services::session();
		
	}

    //--------------------------------------------------------------------

	/**
	 * Displays users page.
	 */
	public function licenseTypes()
	{
		// check if user is signed-in if not redirect to login page
		if (! $this->session->isLoggedIn) {
			return redirect()->to('login');
		}

		// current year and month variable 
		$ym = date("Y-m");

		// load license model
		$license_types = new LicenseTypeModel();

		//get all license types where status = 1
		$alllicense_types = $license_types->findAll();

		// load the view with session data
		return view('auth/license-types', [
				'userData' => $this->session->userData, 
				'data' => $alllicense_types,
			]);
	}

	public function enable()
	{
		// get the license type id
		$id = $this->request->uri->getSegment(3); // get id from url segment /auth/license-types/enable/{id}

		$license_types = new LicenseTypeModel();

		$license_type = [
			'id'  	=> $id,
			'status'  	=> 1,
		];

		if (! $license_types->save($license_type)) {
			return redirect()->back()->withInput()->with('errors', $license_types->errors());
        }

        return redirect()->back()->with('success', lang('App.EnableLicenseTypeSuccess'));
	}

	public function edit()
	{
		// get the license id
		$id = $this->request->uri->getSegment(3);

		// load license type model
		$license_types = new LicenseTypeModel();

		// get license type data using the id
		$license_type = $license_types->where('id', $id)->first(); 

		// load the view with session data
		return view('auth/edits/edit-license-type', [
				'userData' => $this->session->userData, 
				'license_type' => $license_type,
			]);
	}

	public function update()
	{
		$license_types = new LicenseTypeModel();
		$getRule = $license_types->getRule('licensetype');
		$license_types->setValidationRules($getRule);

		$license_type = [
			'id'  	=> $this->request->getPost('id'),
			'name' 	=> $this->request->getPost('name'),
			'status'        => $this->request->getPost('status'),
			
		];

		if (! $license_types->save($license_type)) {
			return redirect()->back()->withInput()->with('errors', $license_types->errors());
        }

        return redirect()->back()->with('success', lang('App.UpdateSuccess'));
	}

	public function delete()
	{
		// get the license type id
		$id = $this->request->uri->getSegment(3);

		// load license model
		$license_types = new LicenseTypeModel();

		// delete license using the id
		$license_types->delete($id);

        return redirect()->back()->with('success', lang('App.LicenseTypeDeleted'));
	}

	public function createLicenseType()
	{
		helper('text'); // esta funcion es para generar un string aleatorio

		// save new license, validation happens in the model
		$license_types = new LicenseTypeModel();
		$getRule = $license_types->getRule('licensetype');
		$license_types->setValidationRules($getRule);
		
        $license_type = [
			'name'          	=> $this->request->getPost('name'),
			'status'          	=> $this->request->getPost('status'),
        ];

        if (! $license_types->save($license_type)) {
			return redirect()->back()->withInput()->with('errors', $license_types->errors());
        }
		// success
        return redirect()->back()->with('success', lang('App.RegisterLicenseTypeSuccess'));
	}


}
