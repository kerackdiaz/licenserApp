<?php
namespace App\Controllers\Auth;

use CodeIgniter\Controller;
use CodeIgniter\I18n\Time;
use Config\Email;
use Config\Services;
use App\Models\LicenseModel;
use App\Models\LicenseTypeModel;

class LicensesController extends Controller
{

	/**
	 * Access to current session.
	 *
	 * @var \CodeIgniter\Session\Session
	 */
	protected $session;

	/**
	 * Authentication settings.
	 */
	protected $config;


    //--------------------------------------------------------------------

	public function __construct()
	{
		// start session
		$this->session = Services::session();
		
	}

    //--------------------------------------------------------------------

	/**
	 * Displays users page.
	 */
	public function licenses()
	{
		// check if user is signed-in if not redirect to login page
		if (! $this->session->isLoggedIn) {
			return redirect()->to('login');
		}

		// current year and month variable 
		$ym = date("Y-m");

		// load license model
		$licenses = new LicenseModel();
		$license_types = new LicenseTypeModel();

		// getall licenses
		$alllicenses = $licenses->findAll();

		//get all license types where status = 1
		$alllicense_types = $license_types->where('status', 1)->findAll();

		setlocale(LC_ALL, 'spanish');
		foreach ($alllicenses as &$license) {
			// convert date yyyy-mm-dd to spanish format
			/*
			$date = Time::createFromFormat('Y-m-d', $license['start_date']);
    		$license['start_date'] = $date->format('d M Y');
			$date = Time::createFromFormat('Y-m-d', $license['end_date']);
			$license['end_date'] = $date->format('d M Y');
			*/
			$date = Time::parse($license['start_date']);
			$fechaEsp = strftime("%d de %B del %Y", $date->getTimestamp()); // strftime esta obsoleto, se puede usar date en su lugar ejem: date("d/m/Y", strtotime($date));
			$license['start_date'] = $fechaEsp;
			$date = Time::parse($license['end_date']);
			$fechaEsp = strftime("%d de %B del %Y", $date->getTimestamp());
			$license['end_date'] = $fechaEsp;
		}	
		
		// count all rows in licenses table
		$countlicenses = $licenses->countAll(); 

		// count all active licenses in the last 30 days
		$newlicenses = $licenses->like("created_at", $ym)->countAllResults(); 

		// count all active licenses
		$activelicenses = $licenses->where('status', 1)->countAllResults(); 

		// calculate active licenses in how many percents
		if ($countlicenses > 0)
			$percentofactivelicenses = round(($activelicenses / $countlicenses) * 100, 2);
		else
			$percentofactivelicenses = 0;
		// load the view with session data
		return view('auth/licenses', [
				'userData' => $this->session->userData, 
				'data' => $alllicenses,
				'license_types' => $alllicense_types,
				'licensescount' => $countlicenses, 
				'newlicenses' => $newlicenses,
				'percentofactivelicenses' => $percentofactivelicenses,
			]);
	}

	public function enable()
	{
		// get the license id
		$id = $this->request->uri->getSegment(3); // obtener el id de la url segmento 3 /auth/enable/id

		$licenses = new LicenseModel();

		$license = [
			'id'  	=> $id,
			'status'  	=> 1,
		];

		if (! $licenses->save($license)) {
			return redirect()->back()->withInput()->with('errors', $licenses->errors());
        }

        return redirect()->back()->with('success', lang('App.EnableLicenseSuccess'));
	}

	public function edit()
	{
		// get the license id
		$id = $this->request->uri->getSegment(3);

		// load license model
		$licenses = new LicenseModel();

		$license_types = new LicenseTypeModel();
		//get all license types where status = 1
		$alllicense_types = $license_types->where('status', 1)->findAll();

		// get license data using the id
		$license = $licenses->where('id', $id)->first(); 

		// load the view with session data
		return view('auth/edits/edit-license', [
				'userData' => $this->session->userData, 
				'license' => $license, 
				'license_types' => $alllicense_types,
			]);
	}

	public function update()
	{
		$licenses = new LicenseModel();
		$getRule = $licenses->getRule('updateLicense');
		$licenses->setValidationRules($getRule);

		$license = [
			'id'  	=> $this->request->getPost('id'),
			'user_name' 	=> $this->request->getPost('user_name'),
			'project_name' 	=> $this->request->getPost('project_name'),
			'project_url' 	=> $this->request->getPost('project_url'),
			'start_date' 	=> date("Y-m-d", strtotime($this->request->getPost('start_date'))),
			'end_date' 		=> date("Y-m-d", strtotime($this->request->getPost('end_date'))),
			'email' 		=> $this->request->getPost('email'),
			'license_type'	=> $this->request->getPost('license_type'),
			'redirect_url'	=> $this->request->getPost('redirect_url'),
			'status'        => $this->request->getPost('status'),
			
		];

		if (! $licenses->save($license)) {
			return redirect()->back()->withInput()->with('errors', $licenses->errors());
        }

        return redirect()->back()->with('success', lang('App.UpdateSuccess'));
	}

	public function delete()
	{
		// get the license id
		$id = $this->request->uri->getSegment(3);

		// load license model
		$licenses = new LicenseModel();

		// delete license using the id
		$licenses->delete($id);

        return redirect()->back()->with('success', lang('App.LicenseDeleted'));
	}

	public function generateLicenseKey(){
		$length = 16;
    	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    	$key = '';
		for ($i = 0; $i < $length; $i++) {
			$key .= $characters[rand(0, strlen($characters) - 1)];
		}
		return $key;
	}

	public function createLicense()
	{
		helper('text'); // esta funcion es para generar un string aleatorio

		// save new license, validation happens in the model
		$licenses = new LicenseModel();
		$getRule = $licenses->getRule('addLicense');
		$licenses->setValidationRules($getRule);
		
        $license = [
			'user_name'          	=> $this->request->getPost('user_name'),
			'project_name'          => $this->request->getPost('project_name'),
			'project_url'          	=> $this->request->getPost('project_url'),
			'start_date'          	=> date("Y-m-d", strtotime($this->request->getPost('start_date'))),
			'end_date'          	=> date("Y-m-d", strtotime($this->request->getPost('end_date'))),
			'email'          		=> $this->request->getPost('email'),
			'license_key'          	=> $this->generateLicenseKey(),
			'license_type'          	=> $this->request->getPost('license_type'),
			'redirect_url'          	=> $this->request->getPost('redirect_url'),
			'status'          	=> $this->request->getPost('status'),
        ];

        if (! $licenses->save($license)) {
			return redirect()->back()->withInput()->with('errors', $licenses->errors());
        }
		// success
        return redirect()->back()->with('success', lang('App.RegisterLicenseSuccess'));
	}

	public function addNewKey()
	{
		// get the license id
		$id = $this->request->uri->getSegment(3); // obtener el id de la url segmento 3 /auth/enable/id

		$licenses = new LicenseModel();

		$license = [
			'id'  	=> $id,
			'license_key'  	=> $this->generateLicenseKey(),
		];

		if (! $licenses->save($license)) {
			return redirect()->back()->withInput()->with('errors', $licenses->errors());
		}

		return redirect()->back()->with('success', lang('App.AddNewKeySuccess'));

	}


}
