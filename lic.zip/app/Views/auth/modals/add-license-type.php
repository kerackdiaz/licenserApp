<div class="modal fade" id="createlicensetypeformmodal" tabindex="-1" role="dialog" aria-labelledby="createlicensetypeformmodal" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createlicencetypeformmodaltitle"><?php echo lang('App.RegisterNewLicenseType') ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?= site_url('license-types/create-license-type'); ?>" method="POST" accept-charset="UTF-8" onsubmit="registerButton.disabled = true; return true;">
            <?= csrf_field() ?>
            <div class="form-group row">
                <div class="col">
                    <label for="user_name"><?php echo lang('App.Name') ?></label>
                    <input class="form-control" required type="text" name="name" value="<?= old('name') ?>" placeholder="<?php echo lang('App.Name') ?>"/>
                </div>
                <div class="col">
                  <label for="status"><?php echo lang('App.Status') ?></label>
                  <select class="form-control" required name="status">
                      <option value="1"><?php echo lang('App.Active') ?></option>
                      <option value="0"><?php echo lang('App.Inactive') ?></option>
                  </select>
                </div>
            </div>

            <div class="text-right">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-times-circle"></i> <?= lang('App.Cancel') ?></button>
                <button type="submit" class="btn btn-primary" name="registerButton"><i class="fas fa-plus-circle"></i> <?= lang('App.Register') ?></button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>