<div class="modal fade" id="createlicenseformmodal" tabindex="-1" role="dialog" aria-labelledby="createlicenseformmodal" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createlicenseformmodaltitle"><?php echo lang('App.RegisterNewLicense') ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?= site_url('licenses/create-license'); ?>" method="POST" accept-charset="UTF-8" onsubmit="registerButton.disabled = true; return true;">
            <?= csrf_field() ?>
            <div class="form-group row">
                <div class="col">
                    <label for="user_name"><?php echo lang('App.UserName') ?></label>
                    <input class="form-control" required type="text" name="user_name" value="<?= old('user_name') ?>" placeholder="<?php echo lang('App.UserName') ?>"/>
                </div>
                <div class="col">
                    <label for="project_name"><?php echo lang('App.ProjectName') ?></label>
                    <input class="form-control" required type="text" name="project_name" value="<?= old('project_name') ?>" placeholder="<?php echo lang('App.ProjectName') ?>"/>
                </div>
            </div>

            <div class="form-group">
                <label for="project_url"><?php echo lang('App.ProjectUrl') ?></label>
                <input class="form-control" required type="text" name="project_url" value="<?= old('project_url') ?>" placeholder="<?php echo lang('App.ProjectUrl') ?>"/>
            </div>

            <div class="form-group">
                <label for="email"><?php echo lang('App.Email') ?></label>
                <input class="form-control" required type="email" name="email" value="<?= old('email') ?>" placeholder="<?= lang('App.Email') ?>"/>
            </div>

            <div class="form-group row">
                <div class="col">
                  <label for="start_date"><?php echo lang('App.StartDate') ?></label>
                  <input class="form-control" required type="date" name="start_date" value="<?= old('start_date') ?>" placeholder="<?php echo lang('App.StartDate') ?>"/>
                </div>
                <div class="col">
                  <label for="end_date"><?php echo lang('App.EndDate') ?></label>
                  <input class="form-control" required type="date" name="end_date" value="<?= old('end_date') ?>" placeholder="<?php echo lang('App.EndDate') ?>"/>
                </div>
            </div>

            <div class="form-group row">
                <div class="col">
                  <label for="license_type"><?php echo lang('App.LicenseType') ?></label>
                  <select class="form-control" required name="license_type">
                      <?php
                      foreach ($license_types as $license_type) {
                          echo '<option value="' . $license_type['id'] . '">' . $license_type['name'] . '</option>';
                      }
                      ?>
                  </select>
                </div>
                <div class="col">
                  <label for="status"><?php echo lang('App.Status') ?></label>
                  <select class="form-control" required name="status">
                      <option value="1"><?php echo lang('App.Active') ?></option>
                      <option value="0"><?php echo lang('App.Inactive') ?></option>
                  </select>
                </div>
            </div>
            <div class="form-group">
                <label for="redirect_url"><?php echo lang('App.RedirectUrl') ?></label>
                <input class="form-control" type="text" name="redirect_url" value="<?= old('redirect_url') ?>" placeholder="<?php echo lang('App.RedirectUrl') ?>"/>
            </div>

            <div class="text-right">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-times-circle"></i> <?= lang('App.Cancel') ?></button>
                <button type="submit" class="btn btn-primary" name="registerButton"><i class="fas fa-plus-circle"></i> <?= lang('App.Register') ?></button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>