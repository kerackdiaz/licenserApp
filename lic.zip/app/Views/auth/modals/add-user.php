<div class="modal fade" id="createuserformmodal" tabindex="-1" role="dialog" aria-labelledby="createuserformmodal" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createuserformmodaltitle"><?php echo lang('App.RegisterNewUser') ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?= site_url('users/create-user'); ?>" method="POST" accept-charset="UTF-8" onsubmit="registerButton.disabled = true; return true;">
            <?= csrf_field() ?>
            <div class="form-group row">
                <div class="col">
                    <label for="firstname"><?php echo lang('App.FirstName') ?></label>
                    <input class="form-control" required type="text" name="firstname" value="<?= old('firstname') ?>" placeholder="<?php echo lang('App.FirstName') ?>"/>
                </div>
                <div class="col">
                    <label for="lastname"><?php echo lang('App.LastName') ?></label>
                    <input class="form-control" required type="text" name="lastname" value="<?= old('lastname') ?>" placeholder="<?php echo lang('App.LastName') ?>"/>
                </div>
            </div>

            <div class="form-group">
                <label for="name"><?php echo lang('App.NickName') ?></label>
                <input class="form-control" required type="text" name="name" value="<?= old('name') ?>" placeholder="<?php echo lang('App.NickName') ?>"/>
            </div>
            <div class="form-group">
                <label for="email"><?php echo lang('App.Email') ?></label>
                <input class="form-control" required type="email" name="email" value="<?= old('email') ?>" placeholder="<?= lang('App.Email') ?>"/>
            </div>
            <div class="form-group">
                <label for="password"><?php echo lang('App.Password') ?></label>
                <input class="form-control" required type="password" name="password" value="" placeholder="<?= lang('App.Password') ?>" />
            </div>
            <div class="form-group">
                <input class="form-control" required type="password" name="password_confirm" value="" placeholder="<?= lang('App.PasswordConfirm') ?>" />
            </div>

            <div class="text-right">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-times-circle"></i> <?= lang('App.Cancel') ?></button>
                <button type="submit" class="btn btn-primary" name="registerButton"><i class="fas fa-plus-circle"></i> <?= lang('App.Register') ?></button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>