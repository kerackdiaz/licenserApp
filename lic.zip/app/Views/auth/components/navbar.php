<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
    <a class="navbar-brand logo-brand" href="#">
      <img height="50" class="logo-img" title="Licenser Logo" alt="Visit CodeIgniter.com official website!" src="/images/logo.svg">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="<?= site_url('account') ?>"><?php echo lang('App.MyAccount') ?></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="<?= site_url('users') ?>"><?php echo lang('App.Users') ?></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="<?= site_url('licenses') ?>"><?php echo lang('App.Licenses') ?></a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="<?= site_url('users/logs') ?>"><?php echo lang('App.Logs') ?></a>
            </li>
        </ul> 

        <ul class="navbar-nav flex-row ml-md-auto d-none d-md-flex">
          <li class="nav-item dropdown">
            <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span class="text-capitalize"><?= $userData['name'] ?></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="bd-versions">
              <a class="dropdown-item" href="<?= site_url('profile') ?>"><?php echo lang('App.Profile') ?> &rarr;</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="<?= site_url('logout') ?>"><?= lang('App.Logout') ?> &rarr;</a>
            </div>
          </li>
        </ul>
    </div>
</nav>