<!-- load main layout with datatable -->
<?= $this->extend('auth/layouts/default-table') ?>

<!-- load modals -->
<?= $this->section('modals') ?>

    <!-- create user modal form -->
    <?= view('App\Views\auth\modals\add-license-type') ?>

<?= $this->endSection() ?>

<!-- load main content -->
<?= $this->section('main') ?>


    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-3">
        <h1 class="h2"><?php echo lang('App.LicenseTypes') ?></h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#createlicensetypeformmodal"><i class="fas fa-plus"></i> <?php echo lang('App.CreateLicenseType') ?></button>
        </div>
    </div>

    <div class="card p-3">
        <div class="table-responsive">
            <table width="100%" class="table table-hover" id="dataTables-table" data-order='[[ 0, "asc" ]]'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th><?php echo lang('App.name') ?></th>
                        <th><?php echo lang('App.Status') ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data as $item):?>
                    <tr>
                        <td><?= $item['id'] ?></td>
                        <td><?= $item['name'] ?></td>

                        <td>
                            <?php 
                            if ($item['status'] == 1) : 
                                echo lang('App.Active');
                            else :
                                echo lang('App.Inactive');
                            endif 
                            ?>
                        </td>
                        <td class="text-right">
                            <?php if ($item['status'] == 0) : ?>
                                <a class="btn btn-outline-secondary btn-sm" href="<?= site_url('license-types/enable/').$item['id'] ?>"><i class="fas fa-check"></i> <?php echo lang('App.Enable') ?></a>
                            <?php endif ?>

                            <a class="btn btn-outline-primary btn-sm" href="<?= site_url('license-types/edit/').$item['id'] ?>"><i class="fas fa-edit"></i> <?php echo lang('App.Edit') ?></a>
                            <a class="btn btn-outline-danger btn-sm" href="<?= site_url('license-types/delete/').$item['id'] ?>" onclick="return confirm('<?php echo lang('App.LicenseTypeAreYouSure') ?>')"><i class="fas fa-trash"></i> <?php echo lang('App.Delete') ?></a>
                        </td>
                    </tr>
                    <?php endforeach;?>
                </tbody>
            </table>
        </div>
    </div>

<?= $this->endSection() ?>