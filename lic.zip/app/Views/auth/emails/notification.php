<p><?php lang('App.AnEmailUpdateRequestOn') ?><?= base_url() ?>!</p>
<p><?php lang('App.IfYouDidntRequestThisChange') ?></p>