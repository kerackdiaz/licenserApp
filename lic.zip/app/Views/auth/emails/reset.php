<p><?php lang('App.PasswordUpdateRequestedOn') ?></p>

<p><?php lang('App.ClickFollowingLinkChangePassword') ?></p>
<p><a href="<?= base_url('reset-password') . '?token=' . $hash ?>"><?= base_url('reset-password') . '?token=' . $hash ?></a></p>

<p><?php lang('App.IfYouDidntRequestThisChange') ?></p>