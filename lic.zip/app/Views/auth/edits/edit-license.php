<!-- load main layout -->
<?= $this->extend('auth/layouts/default') ?>

<!-- load main content -->
<?= $this->section('main') ?>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-3">
        <h1 class="h2"><?php echo lang('App.EditLicense') ?></h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a href="<?= site_url('licenses') ?>" class="btn btn-sm btn-secondary"><i class="fas fa-arrow-left"></i> <?php echo lang('App.Return') ?></a>
        </div>
    </div>

    <div class="card p-3">
        <form action="<?= site_url('licenses/update-license'); ?>" method="POST" accept-charset="UTF-8" onsubmit="Button.disabled = true; return true;">
            <?= csrf_field() ?>
            <div class="form-group row">
                <div class="col">
                    <label for="user_name"><?php echo lang('App.UserName') ?></label>
                    <input class="form-control" required type="text" name="user_name" value="<?= $license['user_name'] ?>" />
                </div>
                <div class="col">
                    <label for="project_name"><?php echo lang('App.ProjectName') ?></label>
                    <input class="form-control" required type="text" name="project_name" value="<?= $license['project_name'] ?>" />
                </div>
            </div>
            <div class="form-group">
                <label for="name"><?php echo lang('App.ProjectUrl') ?></label>
                <input class="form-control" required type="text" name="project_url" value="<?= $license['project_url'] ?>" />
            </div>
            <div class="form-group row">
                <div class="col">
                    <label for="email"><?php echo lang('App.Email') ?></label>
                    <input class="form-control" required type="email" name="email" value="<?= $license['email'] ?>" />
                </div>
                <div class="col">
                    <label for="license_key"><?php echo lang('App.LicenseKey') ?></label>
                    <input class="form-control" readonly type="text" name="license_key" value="<?= $license['license_key'] ?>" />
                </div>
            </div>
            <div class="form-group row">
                <div class="col">
                    <label for="start_date"><?php echo lang('App.StartDate') ?></label>
                    <input class="form-control" required type="date" name="start_date" value="<?= $license['start_date'] ?>" />
                </div>
                <div class="col">
                    <label for="end_date"><?php echo lang('App.EndDate') ?></label>
                    <input class="form-control" required type="date" name="end_date" value="<?= $license['end_date'] ?>" />
                </div>
            </div>
            <div class="form-group row">
                <div class="col">
                    <label for="license_type"><?php echo lang('App.LicenseType') ?></label>
                    <select class="form-control" name="license_type" required>
                        <?php 
                            foreach ($license_types as $license_type) {
                                if ($license['license_type'] === $license_type['id']) {
                                    echo '<option value="'.$license_type['id'].'" selected>'.$license_type['name'].'</option>';
                                } else {
                                    echo '<option value="'.$license_type['id'].'">'.$license_type['name'].'</option>';
                                }
                            }
                        ?>
                    </select>
                </div>
                <div class="col">
                    <label for="status"><?php echo lang('App.Status') ?></label>
                    <select class="form-control" name="status" required>
                        <?php if ($license['status'] === 1) : ?>
                            <option value="1" selected><?php echo lang('App.Enable') ?></option>
                        <?php else : ?>
                            <option value="1"><?php echo lang('App.Enable') ?></option>
                        <?php endif ?>

                        <?php if ($license['status'] === 0) : ?>
                            <option value="0" selected><?php echo lang('App.Disable') ?></option>
                        <?php else : ?>
                            <option value="0"><?php echo lang('App.Disable') ?></option>
                        <?php endif ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="redirect_url"><?php echo lang('App.RedirectUrl') ?></label>
                <input class="form-control" type="text" name="redirect_url" value="<?= $license['redirect_url'] ?>" />
            </div>
            <div class="text-right">
                <input name="id" type="hidden" value="<?= $license['id'] ?>" readonly/>
                <button type="submit" class="btn btn-primary" name="Button"><i class="fas fa-check-circle"></i> <?php echo lang('App.Update') ?></button>
            </div>
        </form>
    </div>

<?= $this->endSection() ?>