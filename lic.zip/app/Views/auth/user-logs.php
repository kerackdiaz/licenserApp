<!-- load main layout with datatable -->
<?= $this->extend('auth/layouts/default-table') ?>

<!-- load main content -->
<?= $this->section('main') ?>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-3">
        <h1 class="h2"><?php echo lang('App.UserLogs') ?></h1>
    </div>

    <div class="card p-3">
        <div class="table-responsive">
            <table width="100%" class="table table-hover" id="dataTables-table" data-order='[[ 0, "desc" ]]'>
                <thead>
                    <tr>
                        <th><?php echo lang('App.Date') ?></th>
                        <th><?php echo lang('App.Time') ?></th>
                        <th><?php echo lang('App.Name') ?></th>
                        <th><?php echo lang('App.IPAddress') ?></th>
                        <!-- <th>Location</th> -->
                        <th><?php echo lang('App.Browser') ?></th>
                        <th><?php echo lang('App.Status') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data as $log):?>
                        <tr>
                            <td><?= $log['date'] ?></td>
                            <td><?= $log['time'] ?></td>
                            <td><?= $log['name'] ?></td>
                            <td><?= $log['ip'] ?></td>
                            <!-- <td>Philippines</td> -->
                            <td><?= $log['browser'] ?></td>
                            <td><?php
                            if ($log['status'] == 'Success') {
                                echo lang('App.LogSuccess');
                            } else {
                                echo lang('App.LogFailed');
                            }
                            ?>
                            </td>
                        </tr>
                    <?php endforeach;?>
                </tbody>
            </table>
        </div>
    </div>

<?= $this->endSection() ?>