<?= $this->extend('auth/layouts/auth') ?>
<?= $this->section('main') ?>

<?= view('App\Views\auth\components\notifications') ?>

<div class="card">
    <div class="card-body text-center">
        <div class="mb-4">
            <img class="brand" height="90" src="/images/logo.svg" alt="Licenser App">
        </div>

        <h6 class="mb-4 text-muted">Inicio de sesión</h6>
       
        <form action="<?= site_url('login'); ?>" method="POST" accept-charset="UTF-8">
            <?= csrf_field() ?>
            <div class="form-group">
                <input name="email" type="email" class="form-control" placeholder="<?= lang('Auth.email') ?>" value="<?= old('email') ?>">
            </div>

            <div class="form-group">
                <input name="password" type="password" class="form-control" placeholder="<?= lang('Auth.password') ?>">
            </div>

            <div class="form-group text-left">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="remember" class="custom-control-input" id="remember-me">
                    <label class="custom-control-label" for="remember-me">Recordarme</label>
                </div>
            </div>
            
            <button class="btn btn-primary shadow-2 mb-4"><?= lang('Auth.login') ?></button>
        </form>

        <p class="mb-2 text-muted"><a href="<?= site_url('forgot-password'); ?>">Olvidaste tu contraseña?</a></p>
    </div>
</div>

<?= $this->endSection() ?>