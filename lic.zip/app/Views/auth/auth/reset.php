<?= $this->extend('auth/layouts/auth') ?>
<?= $this->section('main') ?>

<h1>Restablecer contraseña</h1>

<?= view('App\Views\auth\components\notifications') ?>

<form method="POST" action="<?= site_url('reset-password'); ?>" accept-charset="UTF-8">
    <?= csrf_field() ?>
    <p>
        <label>Nueva contraseña</label><br />
        <input required type="password" name="password" value="" />
    </p>
    <p>
        <label>Repite la nueva contraseña</label><br />
        <input required type="password" name="password_confirm" value="" />
    </p>
    <p>
        <input type="hidden" name="token" value="<?= $_GET['token'] ?>" />
        <button type="submit">Restablecer contraseña</button>
    </p>
</form>

<?= $this->endSection() ?>