<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="generator" content="">
    <title>Licenser App</title>
      <link rel="stylesheet" href="<?= base_url('vendor/fontawesome/css/fontawesome.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('vendor/fontawesome/css/solid.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('vendor/fontawesome/css/brands.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('vendor/bootstrap/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('css/starter-template.css'); ?>">
</head>

<body>

    <!-- main navigation -->
    <?= view('App\Views\auth\components\navbar') ?>

    <!--     
    <div class="nav-scroller bg-white shadow-sm">
        <nav class="nav nav-underline">
            <a class="nav-link active" href="#">Dashboard</a>
            <a class="nav-link" href="#">Friends<span class="badge badge-pill bg-light align-text-bottom">27</span></a>
            <a class="nav-link" href="#">Explore</a>
            <a class="nav-link" href="#">Suggestions</a>
        </nav>
    </div>

    <nav aria-label="breadcrumb">
      <ol class="breadcrumb  mb-0 bg-light">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item"><a href="#">Library</a></li>
        <li class="breadcrumb-item active" aria-current="page">Data</li>
      </ol>
    </nav> 
    -->

    <main role="main" class="">
      <div class="jumbotron bg-light">
          <div class="container heroe">
              <h1 class="font-weight-normal">Bienvenido <span class="text-capitalize"><?= $userData['name'] ?></span>!</h1>
              <h2 class="mt-4 font-weight-light">Ha iniciado sesión.</h2>
          </div>
      </div>
    </main>

    <section>
      <h1>Acerca de Licenser</h1>
      <p>Licenser es una herramienta útil para aquellos que necesitan controlar el acceso y la distribución de sus aplicaciones o sitios web a través de licencias. </p>
      <p>Con Licenser, los desarrolladores pueden generar y distribuir licencias únicas que limitan el uso de su software, lo que permite un control preciso y efectivo sobre el acceso a su aplicación o sitio web.<p>
      <br>
      <p>Licenser cuenta con una interfaz fácil de usar que permite a los usuarios personalizar sus licencias con opciones como la duración de la licencia y las restricciones de uso. </p>
      <p>Además, la herramienta ofrece una gestión completa de licencias, lo que permite a los desarrolladores realizar un seguimiento de las licencias distribuidas y gestionarlas de manera efectiva.</p>
      <p>Con Licenser, los desarrolladores pueden proteger su propiedad intelectual y garantizar que su software sea utilizado de acuerdo con sus términos y condiciones.</p> 
      <p>Esto puede ser especialmente útil para aplicaciones de pago, sitios web de membresía y otras herramientas que requieren una suscripción o acceso limitado. </p>
      <nr>
      <p>En resumen, Licenser es una herramienta poderosa para controlar y proteger el acceso a aplicaciones y sitios web mediante la generación y distribución de licencias personalizadas y únicas.</p>
    </section>

    <footer>
      <div class="copyrights">
        <p class="mb-2 mt-2">&copy; <?= date('Y') ?> Licenser Management.</p>
      </div>
    </footer>

    <script src="<?= base_url("vendor/jquery/jquery.min.js") ?>" type="text/javascript"></script>
    <script src="<?= base_url("vendor/bootstrap/js/bootstrap.bundle.min.js") ?>" type="text/javascript"></script>
</body>

</html>