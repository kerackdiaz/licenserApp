<!-- load main layout with datatable -->
<?= $this->extend('auth/layouts/default-table') ?>

<!-- load modals -->
<?= $this->section('modals') ?>

    <!-- create user modal form -->
    <?= view('App\Views\auth\modals\add-license') ?>

<?= $this->endSection() ?>

<!-- load main content -->
<?= $this->section('main') ?>

    <div class="row">
      <div class="col-sm-4">
        <div class="card mt-3">
          <div class="card-body">
            <h5 class="card-title"><?php echo lang('App.TotalLicenses') ?></h5>
            <h3 class="card-text"><?= $licensescount ?></h3>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="card mt-3">
          <div class="card-body">
            <h5 class="card-title"><?php echo lang('App.NewLicenses') ?></h5>
            <h3 class="card-text"><?= $newlicenses ?> <span class="text-small text-muted"><?php echo lang('App.Inlast30Days') ?></span></h3>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="card mt-3">
          <div class="card-body">
            <h5 class="card-title"><?php echo lang('App.ActiveLicenses') ?></h5>
            <h3 class="card-text"><?= $percentofactivelicenses ?>%</h3>
          </div>
        </div>
      </div>
    </div>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-3">
        <h1 class="h2"><?php echo lang('App.Licenses') ?></h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a class="btn btn-sm btn-primary mr-4" href="<?php echo site_url('license-types') ?>" title="<?php echo lang('App.LicenseTypes') ?>"><i class="fas fa-list"></i> <?php echo lang('App.LicenseTypes') ?></a>
            <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#createlicenseformmodal"><i class="fas fa-plus"></i> <?php echo lang('App.CreateLicense') ?></button>
        </div>
    </div>

    <div class="card p-3">
        <div class="table-responsive">
            <table width="100%" class="table table-hover" id="dataTables-table" data-order='[[ 0, "asc" ]]'>
                <thead>
                    <tr>
                        <th><?php echo lang('App.ProjectName') ?></th>
                        <th><?php echo lang('App.StartDate') ?></th>
                        <th><?php echo lang('App.EndDate') ?></th>
                        <th><?php echo lang('App.Status') ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data as $item):?>
                    <tr>
                        <td><?= $item['project_name'] ?></td>
                        <td><?= $item['start_date'] ?></td>
                        <td><?= $item['end_date'] ?></td>
                        <td>
                            <?php 
                            if ($item['status'] == 1) : 
                                echo lang('App.Active');
                            else :
                                echo lang('App.Inactive');
                            endif 
                            ?>
                        </td>
                        <td class="text-right">
                            <?php if ($item['status'] == 0) : ?>
                                <a class="btn btn-outline-secondary btn-sm" href="<?= site_url('licenses/enable/').$item['id'] ?>"><i class="fas fa-check"></i> <?php echo lang('App.Enable') ?></a>
                            <?php endif ?>

                            <a class="btn btn-outline-primary btn-sm" href="<?= site_url('licenses/edit/').$item['id'] ?>"><i class="fas fa-edit"></i> <?php echo lang('App.Edit') ?></a>
                            <a class="btn btn-outline-danger btn-sm" href="<?= site_url('licenses/delete/').$item['id'] ?>" onclick="return confirm('<?php echo lang('App.LicenseAreYouSure') ?>')"><i class="fas fa-trash"></i> <?php echo lang('App.Delete') ?></a>
                        </td>
                    </tr>
                    <?php endforeach;?>
                </tbody>
            </table>
        </div>
    </div>

<?= $this->endSection() ?>