<?php namespace App\Models;

use CodeIgniter\Model;

class LicenseModel extends Model
{
	protected $table      = 'licenses';
	protected $primaryKey = 'id';

	protected $returnType = 'array';
	protected $useSoftDeletes = false; // si es true, no borra el registro, solo pone la fecha en el campo deleted_at

	// this happens first, model removes all other fields from input data
	protected $allowedFields = [
		'user_name', 'project_name', 'project_url', 'license_key', 'license_type', 'status', 'email', 'start_date', 'end_date',
		'redirect_url', 'is_lifetime'
	];

	protected $useTimestamps = true;
	protected $createdField  = 'created_at';
	protected $updatedField  = 'updated_at';
	protected $dateFormat  	 = 'datetime';

	protected $validationRules = [];

	// we need different rules for registration, account update, etc
	protected $dynamicRules = [
		'addLicense' => [
			'user_name' 		=> 'required|min_length[2]',
			'project_name' 			=> 'required|min_length[2]',
			'project_url' 				=> 'required|min_length[2]|valid_url|is_unique[licenses.project_url]',
			'start_date' 			=> 'required|valid_date[Y-m-d]',
			'end_date' 				=> 'required|valid_date[Y-m-d]',
			'email' 			=> 'required|valid_email',
		],
		'updateLicense' => [
			'id'	=> 'required|is_natural',
			'user_name'	=> 'required|min_length[2]',
			'project_name'	=> 'required|min_length[2]',
			'project_url'	=> 'required|min_length[2]|valid_url|is_unique[licenses.project_url,id,{id}]',
			'start_date'	=> 'required|valid_date[Y-m-d]',
			'end_date'	=> 'required|valid_date[Y-m-d]',
			'email'	=> 'required|valid_email',
		],
		'enableLicense' => [
			'id'	=> 'required|is_natural',
			'status'	=> 'required|integer'
		]
	];

	protected $validationMessages = [];

	protected $skipValidation = false; // si es true, no valida los campos de la tabla



    //--------------------------------------------------------------------

    /**
     * Retrieves validation rule
     */
	public function getRule(string $rule)
	{
		return $this->dynamicRules[$rule];
	}


}
