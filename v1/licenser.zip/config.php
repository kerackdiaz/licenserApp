<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'license_management');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

return [

    'api_key' => '07535868892797410062',
];
