<?php

require_once '../functions.php';
require_once '../LicenseController.php';

header('Content-Type: application/json');

if (!isset($_GET['project_url'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Se requiere la URL del proyecto']);
    exit;
}

$projectUrl = $_GET['project_url'];

$licenseController = new LicenseController();

$license = $licenseController->getLicenseByUrl($projectUrl);

if (!$license) {
    http_response_code(404);
    echo json_encode(['error' => 'Licencia no encontrada']);
    exit;
}

echo json_encode([
    'license_key' => $license->license_key
]);
